// //write a program that includes class shape, atributes of shape, and methods to calculate area of shape rectangle```cpp

// #include<cmath>
// class shape{
//     public:
//     int length;
//     int breadth;
//     public:
//     int CalculateArea(){
//         return length*breadth;
//     }
// };
// int main(){
//     shape s1;
//     s1.length = 5;
//     s1.breadth = 3;
//     std::cout << "Area of shape: " << s1.CalculateArea() << std::endl;
//     return 0;
// }
// ---------------------------------------------------------------------------------------------------------------------------------------------------
// program of inheritance in c++ (class rectangle is inherited from class shape, claculate area and volume of rectangle using inheritance, both parent and child class have their own attributes and methods)

// #include <iostream>
// using namespace std;

// class Shape
// {
// public:
//     int length;
//     int breadth;

//     int CalculateArea()
//     {
//         return length * breadth;
//     }
// };

// class Rectangle : public Shape
// {
// public:
//     int height;

//     int CalculateVolume()
//     {
//         return length * breadth * height;
//     }
// };

// int main()
// {
//     Rectangle r1;

//     r1.length = 10;
//     r1.breadth = 5;
//     r1.height = 5;

//     cout << "Volume = " << r1.CalculateVolume() << endl;
//     cout << "Area = " << r1.CalculateArea() << endl;

//     return 0;
// }

// private specifiers in c++ (private members of parent class are not accessible in child class, but public members of parent class are accessible in child class)
// #include <iostream>
// class Shape{
    
//     private:
//     int length;
//     int breadth;
//     public:
//     int setLength(int l){
//         length = l;
//         return length;
//     }
//     int setBreadth(int b){
//         breadth = b;
//         return breadth; 
//     }
//     // int CalculateArea(){
//     //     return length*breadth;
//     // }
// };
// int main(){
//     Shape s1;
//     Shape s2;
//    std::cout <<"area of shape1: "<<s1.setLength(10)*s1.setBreadth(20)<<std::endl;
//    std::cout <<"area of shape2: "<<s2.setLength(30)*s2.setBreadth(50)<<std::endl;
//     return 0;
// }

// protected specifiers in c++ (protected members of parent class are accessible in child class, but private members of parent class are not accessible in child class)
// #include <iostream>
// using namespace std;
// class Shape{
    
//     protected:
//     int length;
//     int breadth;
//     public:
//     int setInput(int l, int b){
//         length = l;
//         breadth = b;
//     }
// };
// class Rectangle : public Shape{
//     public:
//     int area;
//     int CalculateArea(){
//         area = length*breadth;
//         return area;

//     }
// };
// int main(){
//     Rectangle r1;
//     r1.setInput(20,20);
//     std::cout <<"area of rectangle: "<<r1.CalculateArea()<<std::endl;
//     return 0;
// }

// #include <iostream>
// using namespace std;
// class Student{
// public:
// void display(){
//     cout<<"This is a student class"<<endl;
// }
// };
// student::display(){
//     cout<<"This is a student class"<<endl;
// }

// Default Constructor in c++ 
// #include <iostream>
// using namespace std;
// class Car{
//     public:
//     string brand;
//     string model;
//     int price;

//     // Default constructor
//     public:
//     Car() {
//         brand = "Toyota";
//         model = "Corolla";
//         price = 20000;
//     }
//     public:

//     void display() {
//         cout << "Brand: " << brand << endl;
//         cout << "Model: " << model << endl;
//         cout << "Price: " << price << endl;
        
//     }
// };
// int main(){
//     Car c1;
//     c1.display();
//     cout<< "Size of car: " << sizeof(c1) << endl;
//     return 0;
// }

// Parameterized Constructor in c++
// #include <iostream>
// using namespace std;

// class Shape {
// public:
//     int length;
//     int breadth;
// public:
//     // Parameterized constructor
//     Shape(int l, int b) {
//         length = l;
//         breadth = b;
//     }
// public:
//     int CalculateArea() {
//         return length * breadth;
//     }
// };
// int main(){
//     Shape s1(10, 20);
//     s1.CalculateArea();
//     cout << "Area of shape: " << s1.CalculateArea() << endl;
//     cout<< "Size of shape: " << sizeof(s1) << endl;
//     return 0;
// }

// copy constructor in c++ (copy constructor is used to create a copy of an object, it is called when an object is passed by value, returned by value, or explicitly copied)
// #include <iostream>
// using namespace std;
// class copyconstructor{
//     public:
//     string name;
//     int roll;
//     copyconstructor(string n, int r){
//         name = n;
//         roll = r;
//     }

//     copyconstructor(const copyconstructor &O){
//         name = O.name;
//         roll = O.roll;
        
//     }
//     int display(){
//         cout<<"Name: "<<name<<endl;
//         cout<<"Roll: "<<roll<<endl;
//         return 0;
//     }
//     ~copyconstructor(){
//         cout<<"Destructor called"<<endl;
//     }

// };
// int main(){
    
//     copyconstructor c1("Rajesh", 10);
//     c1.display();
//     copyconstructor c2 = c1; // copy constructor is called here
//     c2.display();
//     cout<< "Size of copyconstructor: " << sizeof(c1) << endl;
//     return 0;
    
// }

// constructor using without dynamic memory allocation in c++ (constructor is used to initialize the object, it is called when an object is created, it can be overloaded, and it can have default arguments)
// #include <iostream>
// using namespace std;
// class constructor{
//     public:
//     int arr[10];
//     int number;
//     constructor(int n){
//         number = n;
//         cout<<"enter the number of elements: "<<endl;
//         cin>>number;
//         for(int i=0; i<number; i++){
//             cin>>arr[i];
//         }
//         int display(){
//             for(int i=0; i<number; i++){
//                 cout<<arr[i]<<" ";
//                 return 0;
//             }
            
//         }
//     }
// };
// int main(){
//     constructor c1(int n);
//     c1.display();
//     return 0;
// }
    
// #include <iostream>
// using namespace std;

// class constructor
// {
// public:
//     int arr[10];
//     int number;

//     constructor(int n)
//     {
//         number = n;

//         cout << "Enter the number of elements: ";
//         cin >> number;

//         cout << "Enter " << number << " elements:" << endl;

//         for(int i = 0; i < number; i++)
//         {
//             cin >> arr[i];
//         }
//     }

//     int display()
//     {
//         cout << "Array elements are: ";

//         for(int i = 0; i < number; i++)
//         {
//             cout << arr[i] << " ";
//         }
//     }
// };

// int main()
// {
//     constructor c1(10); 

//     c1.display();

//     return 0;
// }

// dynamic constructor in c++ (dynamic constructor is used to allocate memory for an object at runtime, it is called when an object is created, it can be overloaded, and it can have default arguments)
// #include <iostream>
// using namespace std;

// class Array {
// public:
//     int *arr;
//     int number;

//     // Constructor
//     Array(int n) {
//         number = n;
//         arr = new int[number];

//         cout << "Enter the array elements: " << endl;
//         for(int i = 0; i < number; i++) {
//             cin >> arr[i];
//         }
//     }

//     // Display function
//     void display() {
//         cout << "Array elements are: " << endl;
//         for(int i = 0; i < number; i++) {
//             cout << arr[i] << " ";
            
//         }
        // ~Array()
        // {
        //     delete[]  arr;
        //     cout<<"Destructor called"<<endl;
        // }
//     }

    
//     };


// int main() {
//     int n;

//     cout << "Enter the number of elements: ";
//     cin >> n;

//     Array c1(n);

//     c1.display();

//     return 0;
// }

// constructor overloading in c++ (constructor overloading is used to create multiple constructors with different parameters, it is called when an object is created, it can be overloaded, and it can have default arguments)
// #include <iostream>
// using namespace std;
// class overloading{
//     private:
//     string name;
//     int roll;
//     int age;

// public:
// overloading(){
//     name = "Null";
//     roll = 0;
//     age = 0;
// }
// overloading(string n){
//     name = n;
//     roll = 0;
//     age = 0;
    
// }
// overloading(string n, int r){
//     name = n;
//     roll = r;
//     age = 0;
// }
// overloading(string n, int r, int a){
//     name = n;
//     roll = r;
//     age = a;
// }
// void display(){
//     cout<<"Name: "<<name<<endl;
//     cout<<"Roll: "<<roll<<endl;
//     cout<<"Age: "<<age<<endl;
// }
// ~overloading(){
//     cout<<"Destructor called"<<endl;
// }
// };
// int main(){
//     overloading o1;
//     overloading o2("Keshav");
//     overloading o3("Keshav", 1);
//     overloading o4("Keshav", 1, 16);
//     o1.display();
//     o2.display();
//     o3.display();
//     o4.display();
//     return 0;
// }

// static data members in c++ (static data members are shared among all objects of a class, they are initialized only once, and they can be accessed using the class name)
// #include <iostream>
// using namespace std;

// class Student {
// public:
//     static int count;

//     Student() {
//         count++;
//     }
// };
// int Student::count = 0;

// int main() {
//     Student s1;
//     Student s2;
//     Student s3;

//     cout << "Total objects: " << Student::count << endl;

//     return 0;
// }

// static data members 2.cpp (static data members are shared among all objects of a class, they are initialized only once, and they can be accessed using the class name)
// #include <iostream>
// using namespace std;
// class Employee{
//     public:
//     static string company;
//     void display(){
//         cout<<"Company: "<<company<<endl;
//     }
// };
// string Employee::company = "Google";
// int main(){
//     Employee e1, e2;
//     e1.display();
//     e2.display();
//     Employee::company = "Microsoft";
//     e1.display();
//     e2.display();
//     return 0;
// }

//static function members in c++ (static function members are shared among all objects of a class, they are initialized only once, and they can be accessed using the class name)
// #include <iostream>
// using namespace std;
//  class Student{
//     public:
//         static void message(){
//         cout<<"Welcome to c++"<<endl;
//     }
//  };
//  int main(){
//     Student::message();
//     return 0;
//  }

//'this' pointer in c++
// #include <iostream>
// using namespace std;

// class Shape {
// public:
//     int length;
//     int breadth;

//     Shape(int length, int breadth) {
//         this->length = length;
//         this->breadth = breadth;
//     }

//     int CalculateArea() {
//         return length * breadth;
//     }
// };

// int main() {
//     Shape s1(10, 5);

//     cout << "Area is " << s1.CalculateArea() << endl;

//     return 0;
// }

//friend function
// #include<iostream>
// using namespace std;
// class Student{
//         private:
//         int marks;
//         public:
//         Student(){
//                 marks=90;
//         }
//         friend void display(Student);
// };
// void display(Student s){
//         cout << "marks="<< s.marks;

// }
// int main(){
//         Student s;
//         display(s);

//         return 0;
// }

// friend function to add object of 2 class using function pass by value
// #include <iostream>
// using namespace std;

// class B;   

// class A {
// private:
//     int num1;

// public:
//     void setData(int x) {
//         num1 = x;
//     }

//     friend void add(A, B);
// };

// class B {
// private:
//     int num2;

// public:
//     void setData(int y) {
//         num2 = y;
//     }

//     friend void add(A, B);
// };


// void add(A a, B b) {
//     cout << "Sum = " << a.num1 + b.num2 << endl;
// }

// int main() {
//     A obj1;
//     B obj2;

//     obj1.setData(10);
//     obj2.setData(20);

//     add(obj1, obj2);

//     return 0;
// }

// friend function to add obj of 2 class using function pass by reference
// #include <iostream>
// using namespace std;

// class B;   

// class A {
// private:
//     int num1=10;

// public:

//     friend void add(A *, B *);   
// };

// class B {
// private:
//     int num2=20;

// public:

//     friend void add(A *, B *);   
// };
// void add(A *a, B *b) {
//     cout << "Sum = " << a->num1 + b->num2 << endl;
// }

// int main() {
//     A obj1;
//     B obj2;

//     add(&obj1, &obj2);   

//     return 0;
// }

